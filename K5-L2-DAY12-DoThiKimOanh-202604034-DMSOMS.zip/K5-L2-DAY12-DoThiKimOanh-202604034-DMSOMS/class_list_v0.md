# Danh sách lớp v0 — Đỗ Thị Kim Oanh · G12

## DMS (ít nhất 6 lớp)

| # | Lớp / thuộc tính | Giá trị | Để làm gì (chức năng DMS) | Nhìn thấy được trên IR? |
|---|---|---|---|---|
| 1 | eye_state | open / closed / unknown | Phát hiện buồn ngủ hoặc nhắm mắt kéo dài | Có, trừ khi kính hoặc ánh sáng che |
| 2 | glasses | none / clear / sun / unknown | Ước lượng khả năng quan sát mắt và chọn tiền xử lý phù hợp | Có thể khó; kính râm NIR không chắc thì unknown |
| 3 | gaze_zone | road / mirror / cluster / center / lap / other | Ước lượng tài xế có nhìn đường hay đang bị phân tâm | Có khi hướng mắt và đầu quan sát rõ |
| 4 | face13 | 13 điểm mặt và occluded/outside | Theo dõi tư thế đầu, gaze proxy và chuyển động khuôn mặt | Có trên NIR; điểm bị che cần cờ |
| 5 | hand | whose / side / on_wheel | Phát hiện tay rời vô lăng và hành vi lái không an toàn | Có, nhưng bố trí khung tọa độ cần theo người |
| 6 | phone | held / mounted / lap | Cảnh báo sử dụng điện thoại và can thiệp phân tâm | Chỉ khi thấy rõ cạnh, góc hoặc màn hình |
| 7 | seatbelt | worn_correct / worn_incorrect / not_worn / unknown | Phát hiện trạng thái thắt dây của tài xế | Có thể bị che hoặc chìm trong bóng tối |

## OMS (ít nhất 6 lớp)

| # | Lớp / thuộc tính | Giá trị | Để làm gì (chức năng OMS) | Nhìn thấy được trên IR? |
|---|---|---|---|---|
| 1 | person | rear_left / rear_middle / rear_right | Nhận diện người trên từng ghế và đếm người | Có |
| 2 | child_seat | occupied=no / unknown; seat theo xe | Kiểm tra ghế trẻ em trống và cấu hình cabin | Có hình dạng, nhưng bên trong có thể che |
| 3 | infant_seat | facing=rear/front; seat theo xe | Nhận diện ghế em bé, hướng và vị trí | Có khi phần hình dạng đủ rõ |
| 4 | object | bag / box / cup / other | Phát hiện đồ vật trên ghế để hỗ trợ quên đồ hoặc cảnh báo | Có bằng hình dạng và ngữ cảnh |
| 5 | seatbelt | not_worn / unknown trên SVIRO | Không suy ra dây an toàn khi dataset không có dây | Không xác định được trong IR mô phỏng |
| 6 | frame_meta | modality / light / camera_blocked | Gắn ngữ cảnh ảnh để hiệu chỉnh tiền xử lý và chất lượng | Có; SVIRO light=unknown |
| 7 | rear seat occupancy | person/object/empty | Đếm số ghế trống, có người hoặc có vật | Có nếu hình dáng rõ trong cả hai chế độ |

## 2 câu hỏi leo thang

1. Câu hỏi: Khi mặt tài xế bị che một phần nhưng vẫn ước lượng được đủ 13 điểm, khi nào một điểm là occluded thay vì outside?
   Khung ví dụ: D06.
   Bạn tạm gán thế nào và vì sao: Gắn outside nếu không thể đoán vị trí an toàn; gắn occluded nếu vị trí có thể suy ra từ đối xứng khuôn mặt.
2. Câu hỏi: Một ghế trẻ em bị phủ đồ và không thấy được bên trong phải dùng occupied=no hay unknown?
   Khung ví dụ: S03, ghế trẻ em trống hoặc che.
   Bạn tạm gán thế nào và vì sao: unknown khi không thể xác định ghế trống; không được dùng occupied=yes.
