# Khai báo dùng AI — Đỗ Thị Kim Oanh

| # | Công cụ | Bạn hỏi gì (tóm tắt) | Bạn dùng kết quả thế nào | Bạn có kiểm lại không? Bằng gì? |
|---|---|---|---|---|
| 1 | Copilot SDK trong VS Code | Hỗ trợ đọc guideline, giải thích guidline | Hướng dẫn chi tiết  | Có. Chạy lại cabin_check; review các lỗi và cảnh báo; không chỉnh XML bằng thủ công ngoài quy tắc |

Không dùng AI để gán nhãn trực tiếp hoặc đọc/cung cấp ảnh cabin cho AI.
