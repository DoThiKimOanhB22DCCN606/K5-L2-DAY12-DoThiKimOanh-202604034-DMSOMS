# Exit ticket — Ngày 12

**Họ tên:** Đỗ Thị Kim Oanh · **Mã:** G12

**Câu 1.** Đáp án: B

Camera 940 nm cho ảnh IR ổn định ngày/đêm và ánh sáng gần hồng ngoại ít làm tài xế chói hơn ánh sáng nhìn thấy.

**Câu 2.** Đáp án: 2.50 s

Số khung từ 240 đến 314 tính cả hai đầu: 314 - 240 + 1 = 75 khung. 75 / 30 = 2.50 giây.

**Câu 3.** Đáp án: A, B, C, D

E sai vì cảnh cabin vẫn cần guideline và QC riêng.
