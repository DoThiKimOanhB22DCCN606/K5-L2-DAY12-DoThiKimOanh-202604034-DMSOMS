# TEAM — Ngày 12

Mã bộ ảnh: **G12** · Hình thức: cá nhân

| Họ tên | MSSV | Đã gán đủ 22 ảnh? | Review chéo với (peer diff) | Số dòng disagreement đã xử lý |
|---|---|---|---|---|
| Đỗ Thị Kim Oanh | 202604034 | có | Nguyễn ĐỨc Hạnh | 93 |

Ca hai bạn vẫn không thống nhất và đã hỏi coach (ghi tên ảnh + đối tượng):

- Nếu phát hiện ca chưa phân xử, ghi tên ảnh và đối tượng cụ thể; bài nộp hiện chưa ghi ca coach bổ sung.

## Cá nhân

### Đỗ Thị Kim Oanh - 202604034

- Phần mình làm: gán và kiểm 22 khung ảnh; tạo export; chạy cabin_check; review chéo với export của duchanhtest703; sửa export và tạo bằng chứng nộp.
- Điều mình học được hôm nay: Ghế và trái/phải phải theo quy ước của xe/người lái, không theo bố trí trong ảnh; unknown là giá trị an toàn khi không quan sát được.
