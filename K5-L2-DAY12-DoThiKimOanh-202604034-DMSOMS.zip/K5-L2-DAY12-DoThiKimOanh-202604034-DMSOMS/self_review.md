# Tự đánh giá — Đỗ Thị Kim Oanh · G12

## 1. Tự rà soát 4 cảnh

| Ảnh | Đối tượng | Loại lỗi | Ghi chú | Đã sửa? |
|---|---|---|---|---|
| D01 | child_seat | extra | Nhãn này không thuộc luồng DMS | Có |
| S01_ir | hand | lr_flip | Hai hand passenger không thể cùng side=right | Có |
| S01_rgb | person/object | seat_flip | Ghế phải gán theo xe, không theo vị trí bên trái ảnh | Có |
| S04_ir | child_seat | seat_flip/guess | Seatbelt và occupied cần tuân thủ guideline; ghế được đặt lại theo xe | Có |

## 2. Lỗi mình lặp lại nhiều nhất hôm nay

Lỗi: Gán default/giá trị đoán như occupied=yes và light=day thay vì unknown/no.

Vì sao mình mắc: Tập trung vẽ hình và quên kiểm thuộc tính theo guideline.

Lần sau tránh bằng cách: Sau mỗi box, mở DETAILS và rà theo checklist; export rồi chạy cabin_check ngay tại checkpoint.

## 3. Ghi chú về disagreement_log

Một dòng bạn của mình đúng và mình sai: Bạn của tôi gán light=unknown cho ảnh SVIRO trong khi tôi dùng day. Mình học được rằng ảnh dựng không có khung giờ trong ngày thực và thuộc tính này phải theo nguồn dữ liệu.
